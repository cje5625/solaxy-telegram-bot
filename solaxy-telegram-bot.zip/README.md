# Solaxy Telegram Bot

Sends price and event alerts for SOLAXY tokens to your personal Telegram.